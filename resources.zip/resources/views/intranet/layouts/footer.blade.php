<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    Copyright &copy; 2019 <strong>Location Véhicule</strong>.
    Tous droits reservés. Propulsée par <a href="https://sparkcorporation.org" target="_blank">Spark Corporation</a>
</footer>