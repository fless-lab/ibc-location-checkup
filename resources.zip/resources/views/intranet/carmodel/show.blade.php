@extends('intranet.layouts.app')

@section('content')

@endsection