<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Historic extends Model
{
    protected $table = 'historics';

    protected $fillable = ['id',

    ];
}
