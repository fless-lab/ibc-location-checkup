<!-- Header -->
<header class="masthead" style="
        background-image: url('{{ url('storage/white_back.jpg') }}')!important;
        background-repeat: no-repeat;
        background-attachment: scroll;
        background-position: center center;
        background-size: cover;
        "
>
    <div class="container">
        <div class="intro-text">
            <div class="intro-lead-in">A partir de <b>{{ $minAmount }} FCFA</b> seulement</div>
            <div class="intro-heading text-uppercase" style="color: steelblue;">Louer votre véhicule à tout moment</div>
            <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">En savoir plus</a>
        </div>
        <div>

        </div>
    </div>
</header>