@php
    use Illuminate\Support\Facades\Auth;
@endphp

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
    <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top"><img src="{{ url('storage/logo.png') }}" style="width: 30%"/></a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            Menu
            <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav text-uppercase ml-auto">
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#portfolio">Véhicules</a>
                </li>

                {{--<li class="nav-item">--}}
                    {{--<a class="nav-link js-scroll-trigger" href="#contact">Contact</a>--}}
                {{--</li>--}}
                @if(Auth::user())
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#reservation">Reservations</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#leasing">Locations</a>
                    </li>
                @endif
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#services">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#team">L'équipe</a>
                </li>
                {{--<li class="nav-item">--}}
                    {{--<a class="nav-link js-scroll-trigger" href="#about">A Propos</a>--}}
                {{--</li>--}}

            </ul>
            <ul class="user-ul">
                @if(Auth::user())
                    @php
                        $user = Auth::user();
                        $photo = $user->photo;
                    @endphp
                    <li>
                        <a class="" href="#" id="sort-down">
                            <img src="{{ url('storage/uploads/avatars/'.$photo) }}" style="width: 40px; height: 40px; border-radius: 50px; object-fit: cover;" alt="">
                            &nbsp;
                            {{ Auth::user()->name }}
                            &nbsp;
                            <i class="fa fa-sort-down"></i>
                        </a>
                    </li>
                    <ul id="user-options" visible="false">
                        <li><a href="{{ route('extranet.editCustomer', [$user->id, $user->type]) }}#contact"><i class="fa fa-user" style="margin-top: -2px !important;"></i> Mon profil </a></li>
                        <li><a href="{{ route('logoutExtranet') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-power-off" style="margin-top: -2px !important;"></i> Déconnexion </a></li>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </ul>
                @else
                    <li>
                        <a class="" href="#contact">Connexion</a>
                    </li>
                @endif
            </ul>

        </div>
    </div>
</nav>

@push('scripts')
    <script>
        $('#sort-down').click(function(){
            var option = $('#user-options')
            if(option.attr('visible') === 'false'){
                option.show()
                option.attr('visible', 'true')
            }else{
                option.hide()
                option.attr('visible', 'false')
            }
        })
    </script>
@endpush