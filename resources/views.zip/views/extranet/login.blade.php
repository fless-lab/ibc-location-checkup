<!-- Connexion -->
<div id="contact-form">
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading text-uppercase">Connexion</h2>
                    <h3 class="section-subheading text-muted">Connectez-vous pour accéder aux reservations et aux locations.</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form action="{{ route('loginExtranet') }}" method="post" >
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input class="form-control" name="email" type="email" placeholder="Votre Email *" required="required" data-validation-required-message="Entrez votre adresse mail SVP enter your email address.">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input class="form-control" name="password" type="password" placeholder="Votre Mot de Passe *" required="required" data-validation-required-message="Entrez votre mot de passe SVP.">
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <button class="btn btn-primary btn-xl text-uppercase" type="submit">Se Connecter</button>
                            </div>
                            <a href="#register-form" id="show-register" style="margin-left: 18px">Créer un compte</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<div id="register-form" style="display: none;">
    @include('extranet.register')
</div>

@push('scripts')
    <script>
        $('#show-register').click(function(){
            $('#register-form').show()
            $('#contact-form').hide()
        })
    </script>
@endpush
