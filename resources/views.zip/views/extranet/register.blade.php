<!-- Register -->
<section id="contact">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="section-heading text-uppercase">Inscription</h2>
                <h3 class="section-subheading text-muted">Inscrivez-vous pour accéder aux reservations et aux locations.
                    <br> * Le client physique sous-entend une personne indépendante.
                    <br> Le client moral représente une société, une entreprise, une compagnie, un groupe etc. *</h3>
                <select id="customer-type">
                    <option value="physical" selected="selected">Client Physique</option>
                    <option value="moral">Client Moral</option>
                </select>
                <br><br>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <form action="{{ route('extranet.storeUser') }}" method="post" id="physical" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="type" value="physical">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Photo</label><br>
                                <input class="form-control" name="photo" type="file" placeholder="Importez votre photo" data-validation-required-message="Entrez votre adresse mail SVP enter your email address.">
                            </div>
                            <div class="form-group">
                                <label>Nom & Prénoms</label><br>
                                <input class="form-control" name="name" type="text" placeholder="Votre Nom & Prénoms *" required="required" data-validation-required-message="Entrez votre adresse mail SVP enter your email address.">
                            </div>
                            <div class="form-group">
                                <label>CNI</label><br>
                                <input class="form-control" name="cni" type="text" placeholder="Votre CNI" >
                            </div>
                            <div class="form-group">
                                <label>Téléphone</label><br>
                                <input class="form-control" name="telephone" type="text" placeholder="Votre Téléphone" >
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Adresse</label><br>
                                <input class="form-control" name="address" type="text" placeholder="Votre adresse" >
                            </div>
                            <div class="form-group">
                                <label>Email</label><br>
                                <input class="form-control" name="email" type="email" placeholder="Votre Email *" required="required" data-validation-required-message="Entrez votre adresse mail SVP enter your email address.">
                            </div>
                            <div class="form-group">
                                <label>Mot de passe</label><br>
                                <input class="form-control" id="password" name="password" type="password" placeholder="Votre Mot de Passe *" required="required" data-validation-required-message="Entrez votre mot de passe SVP.">
                            </div>
                            <div class="form-group">
                                <label>Confirmation de Mot de passe</label>
                                <input type="password" class="form-control" id="confirm" placeholder="Confirmez votre mot de passe">
                                <br>
                                <p id="message" style="font-style: italic; font-size: 12px"></p>
                            </div>
                        </div>

                        <div class="clearfix"></div>
                        <div class="col-lg-12 text-center">
                            <div id="success"></div>
                            <button class="btn btn-primary btn-xl text-uppercase" type="submit">S'inscrire</button>
                        </div>
                    </div>

                </form>

                <form action="{{ route('extranet.storeUser') }}" method="post" id="moral" enctype="multipart/form-data" style="display: none">
                    @csrf
                    <input type="hidden" name="type" value="moral">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Photo</label><br>
                                <input class="form-control" name="photo" type="file" placeholder="Importez votre photo" data-validation-required-message="Entrez votre adresse mail SVP enter your email address.">
                            </div>
                            <div class="form-group">
                                <label>Nom & Prénoms</label><br>
                                <input class="form-control" name="name" type="email" placeholder="Votre Nom & Prénoms *" required="required" data-validation-required-message="Entrez votre adresse mail SVP enter your email address.">
                            </div>
                            <div class="form-group">
                                <label>Nom Ressource</label><br>
                                <input class="form-control" name="resource_name" type="text" placeholder="Nom de la Ressource" >
                            </div>
                            <div class="form-group">
                                <label>Numéro Ressource</label><br>
                                <input class="form-control" name="resource_num" type="text" placeholder="Numéro de la Ressource" >
                            </div>
                            <div class="form-group">
                                <label>Téléphone</label><br>
                                <input class="form-control" name="telephone" type="text" placeholder="Votre Téléphone" >
                            </div>

                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Numéro Opérateur Economique</label><br>
                                <input class="form-control" name="operator_num" type="text" placeholder="Numéro Opérateur Economique" >
                            </div>
                            <div class="form-group">
                                <label>Adresse</label><br>
                                <input class="form-control" name="address" type="text" placeholder="Votre adresse" >
                            </div>
                            <div class="form-group">
                                <label>Email</label><br>
                                <input class="form-control" name="email" type="email" placeholder="Votre Email *" required="required" data-validation-required-message="Entrez votre adresse mail SVP enter your email address.">
                            </div>
                            <div class="form-group">
                                <label>Mot de passe</label><br>
                                <input class="form-control" id="password2" name="password" type="password" placeholder="Votre Mot de Passe *" required="required" data-validation-required-message="Entrez votre mot de passe SVP.">
                            </div>
                            <div class="form-group">
                                <label>Confirmation de Mot de passe</label>
                                <input type="password" class="form-control" id="confirm2" placeholder="Confirmez votre mot de passe">
                                <br>
                                <p id="message2" style="font-style: italic; font-size: 12px"></p>
                            </div>
                        </div>

                        <div class="clearfix"></div>
                        <div class="col-lg-12 text-center">
                            <div id="success"></div>
                            <button class="btn btn-primary btn-xl text-uppercase" type="submit">S'inscrire</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</section>

@push('scripts')
    <script>
        $('#customer-type').change(function(){
            if($(this).val() === 'physical'){
                $('#physical').show();
                $('#moral').hide();
            }else{
                $('#physical').hide();
                $('#moral').show();
            }
        })
    </script>
@endpush